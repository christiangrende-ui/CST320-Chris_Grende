#pragma once
#include "cExprNode.h"
#include "cSymbol.h"
#include "cArgsNode.h"

// call: f(args)
class cCallExprNode : public cExprNode
{
public:
    cCallExprNode(cSymbol* fn, cArgsNode* args)
    {
        AddChild(fn);
        AddChild(args);
    }

    virtual string NodeType() override { return "funcCall"; }
    virtual void Visit(cVisitor* v) override { v->Visit(this); }

    cSymbol* GetFnSym() { return static_cast<cSymbol*>(GetChild(0)); }
    cArgsNode* GetParams() { return static_cast<cArgsNode*>(GetChild(1)); }


    // REQUIRED BY cExprNode
    virtual cDeclNode* GetType() override
    {
        return (GetFnSym() != nullptr && GetFnSym()->GetDecl() != nullptr)
            ? GetFnSym()->GetDecl()->GetType()
            : nullptr;
    }
};